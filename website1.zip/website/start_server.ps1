# PowerShell script to start Coder Matrix Server
Write-Host "Starting Coder Matrix Server..." -ForegroundColor Green
Write-Host ""
python server.py
Write-Host ""
Write-Host "Server stopped. Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

