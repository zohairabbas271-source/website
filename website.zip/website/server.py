#!/usr/bin/env python3
"""
Simple HTTP server with form handling for Coder Matrix website
Uses only Python standard library - no external dependencies
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
import json
import os
from datetime import datetime
import cgi

# Data storage files
INTERNSHIP_APPLICATIONS_FILE = 'internship_applications.json'
BUSINESS_BOOKINGS_FILE = 'business_bookings.json'

def init_data_files():
    """Initialize JSON data files if they don't exist"""
    if not os.path.exists(INTERNSHIP_APPLICATIONS_FILE):
        with open(INTERNSHIP_APPLICATIONS_FILE, 'w') as f:
            json.dump([], f)
    if not os.path.exists(BUSINESS_BOOKINGS_FILE):
        with open(BUSINESS_BOOKINGS_FILE, 'w') as f:
            json.dump([], f)

def load_applications():
    """Load internship applications from JSON file"""
    try:
        with open(INTERNSHIP_APPLICATIONS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_application(data):
    """Save internship application to JSON file"""
    applications = load_applications()
    data['id'] = len(applications) + 1
    data['submitted_at'] = datetime.now().isoformat()
    applications.append(data)
    with open(INTERNSHIP_APPLICATIONS_FILE, 'w') as f:
        json.dump(applications, f, indent=2)
    return data

def load_bookings():
    """Load business bookings from JSON file"""
    try:
        with open(BUSINESS_BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_booking(data):
    """Save business booking to JSON file"""
    bookings = load_bookings()
    data['id'] = len(bookings) + 1
    data['submitted_at'] = datetime.now().isoformat()
    bookings.append(data)
    with open(BUSINESS_BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=2)
    return data

class CoderMatrixHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Route handling
        if path == '/' or path == '/CoderMatrix.html' or path == '/home':
            self.serve_file('CoderMatrix.html', 'text/html')
        elif path == '/apply':
            self.serve_file('templates/apply.html', 'text/html')
        elif path == '/apply/success':
            self.serve_file('templates/apply_success.html', 'text/html')
        elif path == '/business/booking':
            self.serve_file('templates/business_booking.html', 'text/html')
        elif path == '/business/booking/success':
            self.serve_file('templates/booking_success.html', 'text/html')
        elif path.startswith('/static/'):
            # Serve static files
            file_path = path[1:]  # Remove leading /
            if os.path.exists(file_path):
                self.serve_file(file_path)
            else:
                self.send_error(404)
        else:
            self.send_error(404)
    
    def do_POST(self):
        """Handle POST requests (form submissions)"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        if path == '/apply':
            self.handle_application()
        elif path == '/business/booking':
            self.handle_booking()
        else:
            self.send_error(404)
    
    def handle_application(self):
        """Process internship application form submission"""
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        form_data = parse_qs(post_data)
        
        # Extract form data
        data = {
            'full_name': form_data.get('full_name', [''])[0],
            'email': form_data.get('email', [''])[0],
            'phone': form_data.get('phone', [''])[0],
            'domain': form_data.get('domain', [''])[0],
            'experience_level': form_data.get('experience_level', [''])[0],
            'portfolio_url': form_data.get('portfolio_url', [''])[0],
            'github_url': form_data.get('github_url', [''])[0],
            'linkedin_url': form_data.get('linkedin_url', [''])[0],
            'cover_letter': form_data.get('cover_letter', [''])[0],
            'availability': form_data.get('availability', [''])[0],
            'referral_source': form_data.get('referral_source', [''])[0]
        }
        
        # Validate required fields
        required_fields = ['full_name', 'email', 'phone', 'domain', 'experience_level']
        missing_fields = [f for f in required_fields if not data[f]]
        
        if missing_fields:
            # Redirect back to form with error (simplified - in production, use sessions)
            self.send_response(302)
            self.send_header('Location', '/apply?error=missing_fields')
            self.end_headers()
            return
        
        # Save application
        save_application(data)
        
        # Redirect to success page
        self.send_response(302)
        self.send_header('Location', '/apply/success')
        self.end_headers()
    
    def handle_booking(self):
        """Process business booking form submission"""
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        form_data = parse_qs(post_data)
        
        # Extract form data
        data = {
            'company_name': form_data.get('company_name', [''])[0],
            'contact_person': form_data.get('contact_person', [''])[0],
            'email': form_data.get('email', [''])[0],
            'phone': form_data.get('phone', [''])[0],
            'service_type': form_data.get('service_type', [''])[0],
            'project_description': form_data.get('project_description', [''])[0],
            'budget_range': form_data.get('budget_range', [''])[0],
            'timeline': form_data.get('timeline', [''])[0],
            'preferred_contact_method': form_data.get('preferred_contact_method', [''])[0],
            'additional_requirements': form_data.get('additional_requirements', [''])[0]
        }
        
        # Validate required fields
        required_fields = ['company_name', 'contact_person', 'email', 'phone', 'service_type']
        missing_fields = [f for f in required_fields if not data[f]]
        
        if missing_fields:
            # Redirect back to form with error
            self.send_response(302)
            self.send_header('Location', '/business/booking?error=missing_fields')
            self.end_headers()
            return
        
        # Save booking
        save_booking(data)
        
        # Redirect to success page
        self.send_response(302)
        self.send_header('Location', '/business/booking/success')
        self.end_headers()
    
    def serve_file(self, file_path, content_type=None):
        """Serve a file with appropriate content type"""
        if not os.path.exists(file_path):
            self.send_error(404)
            return
        
        # Determine content type
        if content_type is None:
            if file_path.endswith('.html'):
                content_type = 'text/html'
            elif file_path.endswith('.css'):
                content_type = 'text/css'
            elif file_path.endswith('.js'):
                content_type = 'application/javascript'
            elif file_path.endswith('.json'):
                content_type = 'application/json'
            elif file_path.endswith('.png'):
                content_type = 'image/png'
            elif file_path.endswith('.jpg') or file_path.endswith('.jpeg'):
                content_type = 'image/jpeg'
            elif file_path.endswith('.svg'):
                content_type = 'image/svg+xml'
            else:
                content_type = 'application/octet-stream'
        
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
            
            # Replace Flask template syntax with simple replacements for HTML files
            if file_path.endswith('.html'):
                content = content.decode('utf-8')
                # Replace url_for() calls with actual URLs
                content = content.replace("{{ url_for('home') }}", '/CoderMatrix.html')
                content = content.replace("{{ url_for('apply') }}", '/apply')
                content = content.replace("{{ url_for('business_booking') }}", '/business/booking')
                content = content.replace("{{ url_for('apply_success') }}", '/apply/success')
                content = content.replace("{{ url_for('booking_success') }}", '/business/booking/success')
                # Remove Flask template syntax for messages (simplified)
                content = content.replace("{% with messages = get_flashed_messages(with_categories=true) %}", '')
                content = content.replace("{% if messages %}", '')
                content = content.replace("{% for category, message in messages %}", '')
                content = content.replace("{% endfor %}", '')
                content = content.replace("{% endif %}", '')
                content = content.replace("{% endwith %}", '')
                content = content.replace("{{ message }}", '')
                content = content.replace("{{ category }}", '')
                content = content.replace("{{ form_data.", '')
                content = content.replace(" if form_data else '' }}", '')
                content = content.replace("{{ 'selected' if form_data and form_data.", '')
                content = content.replace(" == '", '')
                content = content.replace(" else '' }}", '')
                content = content.replace("{{ url_for('static', filename='css/forms.css') }}", '/static/css/forms.css')
                content = content.encode('utf-8')
            
            self.send_response(200)
            self.send_header('Content-type', content_type)
            self.send_header('Content-length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, str(e))
    
    def log_message(self, format, *args):
        """Override to customize logging"""
        print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {format % args}")

def run(server_class=HTTPServer, handler_class=CoderMatrixHandler, port=8000):
    """Run the server"""
    init_data_files()
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Coder Matrix server running on http://localhost:{port}')
    print(f'Press Ctrl+C to stop the server')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\nShutting down server...')
        httpd.server_close()

if __name__ == '__main__':
    run(port=8000)

