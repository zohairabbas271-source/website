# Transferring from Linux to Windows

## Step-by-Step Transfer Guide

### 1. Copy the Folder

Copy the entire `website` folder from your Linux machine to Windows. You can use:

- **USB Drive**: Copy the folder to a USB drive, then copy to Windows
- **Network Share**: If both machines are on the same network
- **Cloud Storage**: Upload to Google Drive/Dropbox, then download on Windows
- **SCP/SFTP**: If you have SSH access
- **Email**: Zip the folder and email it to yourself (if small enough)

### 2. What to Transfer

Make sure to copy the **entire** `website` folder including:

```
website/
├── server.py
├── start_server.bat          ← Windows startup script
├── start_server.ps1          ← PowerShell script
├── CoderMatrix.html
├── Elevvo.html
├── README.md
├── WINDOWS_SETUP.md           ← Read this on Windows!
├── TRANSFER_GUIDE.md          ← This file
├── templates/
│   ├── CoderMatrix.html
│   ├── apply.html
│   ├── apply_success.html
│   ├── business_booking.html
│   └── booking_success.html
└── static/
    └── css/
        └── forms.css
```

**Note:** The JSON data files (`internship_applications.json` and `business_bookings.json`) will be created automatically when you first run the server, so you don't need to copy them (unless you want to keep existing data).

### 3. On Windows - Install Python (if needed)

1. Check if Python is installed:
   - Open Command Prompt (Win+R, type `cmd`, press Enter)
   - Type: `python --version`
   - If you see a version number (like Python 3.11.x), you're good!

2. If Python is NOT installed:
   - Download from: https://www.python.org/downloads/
   - **IMPORTANT:** During installation, check the box "Add Python to PATH"
   - Complete the installation
   - Restart Command Prompt and verify: `python --version`

### 4. Run on Windows

**Easiest Method:**
1. Navigate to the `website` folder in Windows Explorer
2. Double-click `start_server.bat`
3. A terminal window will open showing the server starting
4. Open your browser to: http://localhost:8000

**Alternative Method:**
1. Open Command Prompt
2. Navigate to the website folder:
   ```cmd
   cd C:\path\to\website
   ```
3. Run:
   ```cmd
   python server.py
   ```

### 5. Verify It Works

1. Server should show: `Coder Matrix server running on http://localhost:8000`
2. Open browser and go to: http://localhost:8000/CoderMatrix.html
3. Click "Apply Now" - should go to application form
4. Click "For Business" - should go to booking form

## Troubleshooting

### "python is not recognized"
- Python is not installed or not in PATH
- Reinstall Python and check "Add Python to PATH"
- Or use full path: `C:\Python3x\python.exe server.py`

### Port 8000 already in use
- Another program is using port 8000
- Close that program or change the port in `server.py` (last line: change `port=8000` to `port=8080`)

### File paths with spaces
- If your folder path has spaces, use quotes:
  ```cmd
  cd "C:\My Documents\website"
  ```

### Firewall warning
- Windows Firewall may ask for permission
- Click "Allow access" to allow the server

## Differences: Linux vs Windows

| Feature | Linux | Windows |
|---------|-------|---------|
| Python command | `python3` | `python` |
| Startup | `python3 server.py` | Double-click `start_server.bat` |
| Path separator | `/` | `\` (but Python handles both) |
| Line endings | LF | CRLF (Python handles both) |

**Good News:** The code is 100% cross-platform! No changes needed when transferring.

## Keeping Your Data

If you want to keep existing applications/bookings:

1. Copy these files from Linux:
   - `internship_applications.json`
   - `business_bookings.json`

2. Paste them into the Windows `website` folder

3. The server will use the existing data

## Need Help?

- Check `WINDOWS_SETUP.md` for detailed Windows instructions
- Check `README.md` for general information
- Make sure Python 3 is installed and in your PATH

