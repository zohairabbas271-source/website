from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from datetime import datetime
import json
import os

app = Flask(__name__)
app.secret_key = 'coder-matrix-secret-key-2024'

# Data storage files
INTERNSHIP_APPLICATIONS_FILE = 'internship_applications.json'
BUSINESS_BOOKINGS_FILE = 'business_bookings.json'

# Initialize data files if they don't exist
def init_data_files():
    if not os.path.exists(INTERNSHIP_APPLICATIONS_FILE):
        with open(INTERNSHIP_APPLICATIONS_FILE, 'w') as f:
            json.dump([], f)
    if not os.path.exists(BUSINESS_BOOKINGS_FILE):
        with open(BUSINESS_BOOKINGS_FILE, 'w') as f:
            json.dump([], f)

# Load data from JSON files
def load_applications():
    try:
        with open(INTERNSHIP_APPLICATIONS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_application(data):
    applications = load_applications()
    data['id'] = len(applications) + 1
    data['submitted_at'] = datetime.now().isoformat()
    applications.append(data)
    with open(INTERNSHIP_APPLICATIONS_FILE, 'w') as f:
        json.dump(applications, f, indent=2)
    return data

def load_bookings():
    try:
        with open(BUSINESS_BOOKINGS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_booking(data):
    bookings = load_bookings()
    data['id'] = len(bookings) + 1
    data['submitted_at'] = datetime.now().isoformat()
    bookings.append(data)
    with open(BUSINESS_BOOKINGS_FILE, 'w') as f:
        json.dump(bookings, f, indent=2)
    return data

@app.route('/')
def index():
    return redirect('/CoderMatrix.html')

@app.route('/CoderMatrix.html')
def home():
    return render_template('CoderMatrix.html')

@app.route('/home')
def home_redirect():
    return redirect('/CoderMatrix.html')

@app.route('/apply', methods=['GET', 'POST'])
def apply():
    if request.method == 'POST':
        data = {
            'full_name': request.form.get('full_name'),
            'email': request.form.get('email'),
            'phone': request.form.get('phone'),
            'domain': request.form.get('domain'),
            'experience_level': request.form.get('experience_level'),
            'portfolio_url': request.form.get('portfolio_url', ''),
            'github_url': request.form.get('github_url', ''),
            'linkedin_url': request.form.get('linkedin_url', ''),
            'cover_letter': request.form.get('cover_letter', ''),
            'availability': request.form.get('availability'),
            'referral_source': request.form.get('referral_source', '')
        }
        
        # Validate required fields
        required_fields = ['full_name', 'email', 'phone', 'domain', 'experience_level']
        for field in required_fields:
            if not data[field]:
                flash(f'Please fill in the {field.replace("_", " ")} field.', 'error')
                return render_template('apply.html', form_data=data)
        
        save_application(data)
        flash('Your application has been submitted successfully! We will contact you soon.', 'success')
        return redirect(url_for('apply_success'))
    
    return render_template('apply.html')

@app.route('/apply/success')
def apply_success():
    return render_template('apply_success.html')

@app.route('/business/booking', methods=['GET', 'POST'])
def business_booking():
    if request.method == 'POST':
        data = {
            'company_name': request.form.get('company_name'),
            'contact_person': request.form.get('contact_person'),
            'email': request.form.get('email'),
            'phone': request.form.get('phone'),
            'service_type': request.form.get('service_type'),
            'project_description': request.form.get('project_description', ''),
            'budget_range': request.form.get('budget_range'),
            'timeline': request.form.get('timeline'),
            'preferred_contact_method': request.form.get('preferred_contact_method'),
            'additional_requirements': request.form.get('additional_requirements', '')
        }
        
        # Validate required fields
        required_fields = ['company_name', 'contact_person', 'email', 'phone', 'service_type']
        for field in required_fields:
            if not data[field]:
                flash(f'Please fill in the {field.replace("_", " ")} field.', 'error')
                return render_template('business_booking.html', form_data=data)
        
        save_booking(data)
        flash('Your booking request has been submitted successfully! We will contact you within 24 hours.', 'success')
        return redirect(url_for('booking_success'))
    
    return render_template('business_booking.html')

@app.route('/business/booking/success')
def booking_success():
    return render_template('booking_success.html')

@app.route('/admin/applications')
def admin_applications():
    applications = load_applications()
    return jsonify(applications)

@app.route('/admin/bookings')
def admin_bookings():
    bookings = load_bookings()
    return jsonify(bookings)

if __name__ == '__main__':
    init_data_files()
    app.run(debug=True, host='0.0.0.0', port=5000)

