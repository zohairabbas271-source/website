# Running Coder Matrix on Windows

## Quick Start Guide

### Method 1: Using Batch File (Easiest)
1. Double-click `start_server.bat`
2. The server will start automatically
3. Open your browser and go to: http://localhost:8000

### Method 2: Using PowerShell Script
1. Right-click `start_server.ps1`
2. Select "Run with PowerShell"
3. If you get an execution policy error, run this first in PowerShell (as Administrator):
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

### Method 3: Using Command Prompt
1. Open Command Prompt (cmd) or PowerShell
2. Navigate to the project folder:
   ```cmd
   cd path\to\website
   ```
3. Run the server:
   ```cmd
   python server.py
   ```

## Prerequisites

### Python Installation
Make sure Python 3 is installed on your Windows system:

1. **Check if Python is installed:**
   ```cmd
   python --version
   ```
   or
   ```cmd
   python3 --version
   ```

2. **If Python is not installed:**
   - Download from: https://www.python.org/downloads/
   - During installation, check "Add Python to PATH"
   - Verify installation by running `python --version` in Command Prompt

## Accessing the Website

Once the server is running, open your web browser and visit:

- **Home Page**: http://localhost:8000/CoderMatrix.html
- **Apply for Internship**: http://localhost:8000/apply
- **Business Booking**: http://localhost:8000/business/booking

## Stopping the Server

- Press `Ctrl+C` in the terminal window
- Or close the terminal window

## File Structure (Windows)

```
website/
├── server.py                      # Main server file
├── start_server.bat               # Windows batch file (double-click to run)
├── start_server.ps1               # PowerShell script
├── CoderMatrix.html               # Main homepage
├── templates/                      # HTML templates
│   ├── CoderMatrix.html
│   ├── apply.html
│   ├── apply_success.html
│   ├── business_booking.html
│   └── booking_success.html
├── static/
│   └── css/
│       └── forms.css
├── internship_applications.json    # Created automatically
└── business_bookings.json          # Created automatically
```

## Troubleshooting

### "python is not recognized"
- Python is not in your PATH
- Reinstall Python and check "Add Python to PATH"
- Or use full path: `C:\Python3x\python.exe server.py`

### Port 8000 already in use
- Another application is using port 8000
- Close that application or modify `server.py` to use a different port
- Change `port=8000` to `port=8080` at the bottom of `server.py`

### Permission errors
- Make sure you have write permissions in the folder
- Run Command Prompt as Administrator if needed

### Firewall warnings
- Windows Firewall may ask for permission
- Click "Allow access" to allow the server to run

## Notes

- The server uses only Python standard library - no additional packages needed
- All data is stored in JSON files in the same folder
- The server will create `internship_applications.json` and `business_bookings.json` automatically
- Works the same way as on Linux - fully cross-platform!

## Transferring from Linux to Windows

1. Copy the entire `website` folder to your Windows machine
2. Make sure Python 3 is installed on Windows
3. Use any of the methods above to start the server
4. That's it! No code changes needed.

