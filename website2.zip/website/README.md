# Coder Matrix Website

A fully functional website for Coder Matrix with internship applications and business booking system.

## Features

- **Home Page**: Beautiful landing page with all company information
- **Internship Applications**: Users can apply for internships in 5 domains:
  - Natural Language Processing (NLP)
  - Machine Learning (ML)
  - Data Analysis
  - Web Development
  - UI/UX Design
- **Business Booking**: Businesses can book services including:
  - Data Analysis and Reporting
  - Machine Learning Model Development
  - Custom Dashboards (Power BI, Tableau)
  - Full-Stack Web Development
  - UI/UX Design and Prototyping
  - Automation and Scraping Solutions
  - General Consultation

## Running the Server

The server uses Python's built-in HTTP server (no external dependencies required). **Works on both Linux and Windows!**

### Linux/Mac

```bash
python3 server.py
```

### Windows

**Option 1 (Easiest):** Double-click `start_server.bat`

**Option 2:** Open Command Prompt and run:
```cmd
python server.py
```

**Option 3:** Use PowerShell script `start_server.ps1`

> 📖 **For detailed Windows setup instructions, see [WINDOWS_SETUP.md](WINDOWS_SETUP.md)**

The server will start on `http://localhost:8000`

### Access the Website

- **Home Page**: http://localhost:8000/CoderMatrix.html
- **Apply for Internship**: http://localhost:8000/apply
- **Business Booking**: http://localhost:8000/business/booking

## Data Storage

All applications and bookings are stored in JSON files:
- `internship_applications.json` - All internship applications
- `business_bookings.json` - All business booking requests

## Project Structure

```
website/
├── server.py                 # Main server file
├── start_server.bat          # Windows startup script
├── start_server.ps1          # PowerShell startup script
├── CoderMatrix.html          # Main homepage (also in templates/)
├── WINDOWS_SETUP.md          # Windows-specific instructions
├── templates/
│   ├── CoderMatrix.html      # Homepage template
│   ├── apply.html            # Internship application form
│   ├── apply_success.html    # Application success page
│   ├── business_booking.html # Business booking form
│   └── booking_success.html  # Booking success page
├── static/
│   └── css/
│       └── forms.css         # Form styling
├── internship_applications.json  # Application data (auto-created)
└── business_bookings.json       # Booking data (auto-created)
```

## How It Works

1. **Form Submissions**: When users submit forms, the data is:
   - Validated for required fields
   - Saved to JSON files with timestamps
   - Users are redirected to success pages

2. **Data Storage**: All submissions are stored in JSON format with:
   - Unique ID
   - Submission timestamp
   - All form data

3. **No Database Required**: Uses simple JSON file storage - perfect for development and small-scale deployments

## Stopping the Server

Press `Ctrl+C` in the terminal where the server is running.

**Linux/Mac alternative:**
```bash
pkill -f server.py
```

## Notes

- The server handles all routing and form processing
- All forms include validation
- Success pages confirm submission
- Data persists between server restarts

